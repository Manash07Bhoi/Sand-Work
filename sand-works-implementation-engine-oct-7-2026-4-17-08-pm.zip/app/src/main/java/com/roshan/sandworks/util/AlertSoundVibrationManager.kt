package com.roshan.sandworks.util

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.roshan.sandworks.MainActivity
import com.roshan.sandworks.R
import com.roshan.sandworks.SandWorksApp

object AlertSoundVibrationManager {

    private const val TAG = "AlertSoundVibMgr"
    private var activeRingtone: Ringtone? = null

    /**
     * Triggers real audible alert sound and physical vibration on the device.
     * Works on all installed apps/devices regardless of whether the user is logged in or not.
     * The alert message is optional.
     */
    fun triggerAlert(
        context: Context,
        title: String,
        message: String?,
        isEmergency: Boolean = true
    ) {
        val appContext = context.applicationContext

        val safeTitle = title.trim().ifEmpty {
            if (isEmergency) "OPERATIONAL EMERGENCY ALERT" else "SAND WORKS NOTIFICATION"
        }
        val safeMessage = message?.trim().orEmpty()

        Log.i(TAG, "Triggering real alert: title='$safeTitle', isEmergency=$isEmergency")

        // 1. Play Real Alert Sound (using system Alarm / Notification stream)
        playAlertSound(appContext, isEmergency)

        // 2. Perform Real Physical Vibration
        performVibration(appContext, isEmergency)

        // 3. Post High-Importance System Notification (Heads-Up)
        postSystemNotification(appContext, safeTitle, safeMessage, isEmergency)
    }

    private fun playAlertSound(context: Context, isEmergency: Boolean) {
        try {
            // Stop any currently playing ringtone to avoid overlapping loops
            stopAlertSound()

            val soundType = if (isEmergency) {
                RingtoneManager.TYPE_ALARM
            } else {
                RingtoneManager.TYPE_NOTIFICATION
            }

            var soundUri: Uri? = RingtoneManager.getDefaultUri(soundType)
            if (soundUri == null) {
                soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            }

            if (soundUri != null) {
                val ringtone = RingtoneManager.getRingtone(context, soundUri)
                if (ringtone != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        ringtone.audioAttributes = AudioAttributes.Builder()
                            .setUsage(if (isEmergency) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                            .build()
                    }
                    ringtone.play()
                    activeRingtone = ringtone
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Ringtone playback error: ${e.message}")
        }

        // Secondary / Fallback sound generator using ToneGenerator
        // Ensures loud audio response on emulators or devices without pre-packaged ringtone files
        try {
            val streamType = if (isEmergency) AudioManager.STREAM_ALARM else AudioManager.STREAM_NOTIFICATION
            val toneGen = ToneGenerator(streamType, 100)
            val toneType = if (isEmergency) {
                ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK
            } else {
                ToneGenerator.TONE_PROP_BEEP2
            }
            toneGen.startTone(toneType, if (isEmergency) 1500 else 600)
        } catch (e: Exception) {
            Log.w(TAG, "ToneGenerator fallback error: ${e.message}")
        }
    }

    private fun performVibration(context: Context, isEmergency: Boolean) {
        try {
            val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator ?: (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator != null && vibrator.hasVibrator()) {
                // Waveform: wait 0ms, vibrate 600ms, pause 200ms, vibrate 600ms, pause 200ms, vibrate 1000ms
                val pattern = if (isEmergency) {
                    longArrayOf(0, 600, 200, 600, 200, 1000)
                } else {
                    longArrayOf(0, 300, 150, 300)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val audioAttributes = AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(if (isEmergency) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION)
                        .build()
                    val effect = VibrationEffect.createWaveform(pattern, -1)
                    vibrator.vibrate(effect, audioAttributes)
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(pattern, -1)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibration execution error: ${e.message}")
        }
    }

    private fun postSystemNotification(
        context: Context,
        title: String,
        message: String,
        isEmergency: Boolean
    ) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            val channelId = if (isEmergency) {
                SandWorksApp.CHANNEL_EMERGENCY
            } else {
                SandWorksApp.CHANNEL_BROADCAST
            }

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                (System.currentTimeMillis() % 10000).toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val soundUri = if (isEmergency) {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            } else {
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            }

            val displayText = if (message.isBlank()) {
                if (isEmergency) "Immediate operational attention required on site." else "Operational update."
            } else {
                message
            }

            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(displayText)
                .setStyle(NotificationCompat.BigTextStyle().bigText(displayText))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setPriority(if (isEmergency) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
                .setCategory(if (isEmergency) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_MESSAGE)
                .setSound(soundUri)
                .setVibrate(if (isEmergency) longArrayOf(0, 600, 200, 600, 200, 1000) else longArrayOf(0, 300, 150, 300))

            notificationManager.notify((System.currentTimeMillis() % 100000).toInt(), builder.build())
        } catch (e: Exception) {
            Log.w(TAG, "Failed to post system notification: ${e.message}")
        }
    }

    fun stopAlertSound() {
        try {
            activeRingtone?.stop()
            activeRingtone = null
        } catch (_: Exception) {}
    }
}
