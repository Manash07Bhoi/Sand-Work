package com.roshan.sandworks

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import com.roshan.sandworks.util.AlertSoundVibrationManager
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

class SandWorksApp : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            FirebaseApp.initializeApp(this)
        } catch (_: Exception) {}

        // Initialize Firebase App Check
        initAppCheck()

        // Create FCM Notification Channels
        createNotificationChannels()

        // Enable FCM and subscribe to emergency topics across all installed devices
        initFcmSubscriptions()

        // Start global background alert monitoring so any installed app receives real sound & vibration
        startGlobalAlertMonitoring()
    }

    private fun initAppCheck() {
        try {
            val appCheck = FirebaseAppCheck.getInstance()
            if (BuildConfig.DEBUG) {
                // Debug provider for local JVM / emulator / development
                appCheck.installAppCheckProviderFactory(
                    DebugAppCheckProviderFactory.getInstance()
                )
            } else {
                // Play Integrity for genuine production Android devices
                appCheck.installAppCheckProviderFactory(
                    PlayIntegrityAppCheckProviderFactory.getInstance()
                )
            }
        } catch (_: Exception) {
            // Gracefully handle environments without Google Play Services
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // 1. Emergency Alerts Channel (Urgent, High Importance, Vibration)
            val emergencyChannel = NotificationChannel(
                CHANNEL_EMERGENCY,
                "Emergency Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical site warnings and urgent operational alerts"
                enableVibration(true)
                enableLights(true)
            }

            // 2. Broadcast Messages Channel
            val broadcastChannel = NotificationChannel(
                CHANNEL_BROADCAST,
                "Team Broadcasts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Operational messages and directives from the Owner"
            }

            // 3. Daily Accrual Summaries Channel
            val accrualChannel = NotificationChannel(
                CHANNEL_ACCRUALS,
                "Daily Accrual Summaries",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "End-of-day accrued money accounting summaries"
            }

            notificationManager.createNotificationChannels(
                listOf(emergencyChannel, broadcastChannel, accrualChannel)
            )
        }
    }

    private fun initFcmSubscriptions() {
        try {
            val messaging = FirebaseMessaging.getInstance()
            messaging.isAutoInitEnabled = true
            messaging.subscribeToTopic("emergency_alerts")
            messaging.subscribeToTopic("all_devices")
        } catch (e: Exception) {
            Log.w("SandWorksApp", "FCM topic subscription note: ${e.message}")
        }
    }

    /**
     * Listens for operational emergency alerts in Firestore continuously.
     * Fires real sound and physical vibration on all installed devices regardless of whether
     * the user is logged in or unauthenticated. Alert messages are completely optional.
     */
    private fun startGlobalAlertMonitoring() {
        try {
            val firestore = FirebaseFirestore.getInstance()
            val launchTime = System.currentTimeMillis() - 30_000L // last 30 sec or future

            firestore.collection("emergency_alerts")
                .addSnapshotListener { snapshot, error ->
                    if (error != null || snapshot == null) return@addSnapshotListener

                    for (change in snapshot.documentChanges) {
                        if (change.type == DocumentChange.Type.ADDED) {
                            val doc = change.document
                            val timestamp = doc.getLong("timestamp") ?: 0L
                            val id = doc.id

                            // Only trigger audible alert/vibration if added recently/after app start
                            if (timestamp >= launchTime && !triggeredAlertIds.contains(id)) {
                                triggeredAlertIds.add(id)
                                val title = doc.getString("title") ?: "OPERATIONAL EMERGENCY ALERT"
                                val message = doc.getString("message") // optional!

                                AlertSoundVibrationManager.triggerAlert(
                                    context = this@SandWorksApp,
                                    title = title,
                                    message = message,
                                    isEmergency = true
                                )
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w("SandWorksApp", "Global alert listener setup note: ${e.message}")
        }
    }

    companion object {
        @Volatile
        lateinit var instance: SandWorksApp
            private set

        fun getSafeInstance(): SandWorksApp? {
            return try {
                if (::instance.isInitialized) instance else null
            } catch (_: Throwable) {
                null
            }
        }

        const val CHANNEL_EMERGENCY = "sandworks_emergency_channel"
        const val CHANNEL_BROADCAST = "sandworks_broadcast_channel"
        const val CHANNEL_ACCRUALS = "sandworks_accruals_channel"

        private val triggeredAlertIds = Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

        fun markAlertTriggered(alertId: String) {
            triggeredAlertIds.add(alertId)
        }
    }
}

