package com.roshan.sandworks.data

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.roshan.sandworks.MainActivity
import com.roshan.sandworks.R
import com.roshan.sandworks.SandWorksApp
import com.roshan.sandworks.util.AlertSoundVibrationManager

class SandWorksMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        try {
            // Register token with current user document if authenticated
            val uid = FirebaseAuth.getInstance().currentUser?.uid
            if (!uid.isNullOrBlank()) {
                FirebaseFirestore.getInstance().collection("users").document(uid)
                    .update("fcmToken", token)
            }
        } catch (_: Exception) {
            // Gracefully ignore registration failure in offline/emulator environment
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        try {
            val title = remoteMessage.data["title"] ?: remoteMessage.notification?.title ?: "SAND WORKS Alert"
            val body = remoteMessage.data["message"] ?: remoteMessage.notification?.body // message is optional
            val type = remoteMessage.data["type"] ?: "EMERGENCY"
            val alertId = remoteMessage.data["alertId"]

            if (!alertId.isNullOrBlank()) {
                SandWorksApp.markAlertTriggered(alertId)
            }

            val isEmergency = type == "EMERGENCY" || type == "ALERT"

            // 1. Trigger real audible alert sound and physical vibration on the device
            AlertSoundVibrationManager.triggerAlert(
                context = this,
                title = title,
                message = body,
                isEmergency = isEmergency
            )
        } catch (_: Exception) {
            // Gracefully ignore notification failure
        }
    }
}

