package com.roshan.sandworks.ui.components

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.roshan.sandworks.domain.MoneyEngine
import com.roshan.sandworks.model.*
import com.roshan.sandworks.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Filter state data class for the Trip History view
 */
data class TripHistoryFilterState(
    val searchQuery: String = "",
    val datePreset: String = "ALL", // ALL, TODAY, YESTERDAY, THIS_WEEK, LAST_30_DAYS, CUSTOM_RANGE
    val startDate: String = "",     // yyyy-MM-dd
    val endDate: String = "",       // yyyy-MM-dd
    val selectedDriverId: String = "ALL",
    val selectedTractorId: String = "ALL",
    val filterStatus: String = "ALL" // ALL, ACTIVE, VOIDED
) {
    val isAnyFilterActive: Boolean
        get() = searchQuery.isNotBlank() ||
                datePreset != "ALL" ||
                selectedDriverId != "ALL" ||
                selectedTractorId != "ALL" ||
                filterStatus != "ALL"
}

/**
 * Comprehensive UI Component for the 'Trip History' view.
 * Includes date range pickers, dropdown filters for driver and vehicle,
 * search query, financial auditing summary, loading, empty, and error states.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripHistoryView(
    trips: List<Trip>,
    users: List<User>,
    tractors: List<Tractor>,
    currentUser: User?,
    isLoading: Boolean = false,
    errorMessage: String? = null,
    onRetry: (() -> Unit)? = null,
    onLogTripClick: (() -> Unit)? = null,
    onVoidTrip: ((Trip, String) -> Unit)? = null,
    onEditTrip: ((Trip) -> Unit)? = null,
    onExportAudit: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val now = remember { System.currentTimeMillis() }
    val todayDate = remember { sdf.format(Date(now)) }
    val yesterdayDate = remember { sdf.format(Date(now - 86400000L)) }
    val sevenDaysAgoMillis = remember { now - 7L * 86400000L }
    val thirtyDaysAgoMillis = remember { now - 30L * 86400000L }

    // Filter state
    var filterState by remember { mutableStateOf(TripHistoryFilterState()) }

    // UI Dialog states
    var showCustomDateRangeDialog by remember { mutableStateOf(false) }
    var viewingTripDetails by remember { mutableStateOf<Trip?>(null) }
    var tripToVoid by remember { mutableStateOf<Trip?>(null) }
    var voidReasonInput by remember { mutableStateOf("") }
    var voidReasonError by remember { mutableStateOf(false) }
    var exportPreviewText by remember { mutableStateOf<String?>(null) }

    // Dropdown expanded states
    var driverDropdownExpanded by remember { mutableStateOf(false) }
    var vehicleDropdownExpanded by remember { mutableStateOf(false) }
    var statusDropdownExpanded by remember { mutableStateOf(false) }

    // Distinct list of drivers
    val driverOptions = remember(users, trips) {
        val fromUsers = users.filter { it.role == Role.DRIVER }.map { it.uid to it.fullName }
        val fromTrips = trips.map { it.driverId to it.driverName }
        (fromUsers + fromTrips)
            .filter { it.first.isNotBlank() }
            .distinctBy { it.first }
    }

    // Distinct list of vehicles / tractors
    val tractorOptions = remember(tractors, trips) {
        val fromTractors = tractors.map { it.id to "${it.name} (${it.registrationNumber})" }
        val fromTrips = trips.map { it.tractorId to it.tractorName }
        (fromTractors + fromTrips)
            .filter { it.first.isNotBlank() }
            .distinctBy { it.first }
    }

    // Filter computation
    val filteredTrips = remember(trips, filterState) {
        trips.filter { trip ->
            // 1. Date Range matching
            val matchesDate = when (filterState.datePreset) {
                "TODAY" -> trip.date == todayDate
                "YESTERDAY" -> trip.date == yesterdayDate
                "THIS_WEEK" -> trip.timestamp >= sevenDaysAgoMillis
                "LAST_30_DAYS" -> trip.timestamp >= thirtyDaysAgoMillis
                "CUSTOM_RANGE" -> {
                    val sDate = filterState.startDate.trim()
                    val eDate = filterState.endDate.trim()
                    if (sDate.isNotEmpty() && eDate.isNotEmpty()) {
                        trip.date in sDate..eDate
                    } else if (sDate.isNotEmpty()) {
                        trip.date >= sDate
                    } else if (eDate.isNotEmpty()) {
                        trip.date <= eDate
                    } else true
                }
                else -> true
            }

            // 2. Driver filter
            val matchesDriver = if (filterState.selectedDriverId == "ALL") true
            else trip.driverId == filterState.selectedDriverId

            // 3. Vehicle / Tractor filter
            val matchesVehicle = if (filterState.selectedTractorId == "ALL") true
            else trip.tractorId == filterState.selectedTractorId

            // 4. Status filter
            val matchesStatus = when (filterState.filterStatus) {
                "ACTIVE" -> trip.status == TripStatus.ACTIVE
                "VOIDED" -> trip.status == TripStatus.VOIDED
                else -> true
            }

            // 5. Search query
            val q = filterState.searchQuery.trim()
            val matchesSearch = q.isEmpty() ||
                    trip.tripNumber.toString().contains(q) ||
                    trip.driverName.contains(q, ignoreCase = true) ||
                    trip.tractorName.contains(q, ignoreCase = true) ||
                    trip.labourerNames.any { it.contains(q, ignoreCase = true) } ||
                    trip.date.contains(q) ||
                    (trip.voidReason?.contains(q, ignoreCase = true) == true)

            matchesDate && matchesDriver && matchesVehicle && matchesStatus && matchesSearch
        }
    }

    // Financial Audit aggregations
    val activeTrips = remember(filteredTrips) { filteredTrips.filter { it.status == TripStatus.ACTIVE } }
    val voidedTripsCount = remember(filteredTrips) { filteredTrips.count { it.status == TripStatus.VOIDED } }
    val totalAccruedPoolPaise = remember(activeTrips) { activeTrips.sumOf { it.totalPoolPaise } }
    val totalDriverSharePaise = remember(activeTrips) {
        activeTrips.sumOf { it.sharesPaise[it.driverId] ?: 0L }
    }
    val totalLabourerSharePaise = remember(totalAccruedPoolPaise, totalDriverSharePaise) {
        totalAccruedPoolPaise - totalDriverSharePaise
    }

    val selectedDriverName = remember(filterState.selectedDriverId, driverOptions) {
        if (filterState.selectedDriverId == "ALL") "All Drivers (${driverOptions.size})"
        else driverOptions.find { it.first == filterState.selectedDriverId }?.second ?: "Selected Driver"
    }

    val selectedTractorName = remember(filterState.selectedTractorId, tractorOptions) {
        if (filterState.selectedTractorId == "ALL") "All Vehicles (${tractorOptions.size})"
        else tractorOptions.find { it.first == filterState.selectedTractorId }?.second ?: "Selected Vehicle"
    }

    val selectedStatusName = when (filterState.filterStatus) {
        "ACTIVE" -> "Completed (Active)"
        "VOIDED" -> "Voided Records"
        else -> "All Statuses"
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("trip_history_component")
    ) {
        // --- 1. Header & Actions ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Trip History & Financial Audit",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Filter completed trips by date range, driver, or vehicle",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        val dateRangeDesc = when (filterState.datePreset) {
                            "TODAY" -> "Today ($todayDate)"
                            "YESTERDAY" -> "Yesterday ($yesterdayDate)"
                            "THIS_WEEK" -> "Last 7 Days"
                            "LAST_30_DAYS" -> "Last 30 Days"
                            "CUSTOM_RANGE" -> "Range ${filterState.startDate} to ${filterState.endDate}"
                            else -> "All History"
                        }
                        val breakdownDesc = if (filterState.selectedDriverId != "ALL") "Driver: $selectedDriverName"
                        else if (filterState.selectedTractorId != "ALL") "Vehicle: $selectedTractorName"
                        else "All Fleet & Team"

                        val summary = buildString {
                            appendLine("==============================================")
                            appendLine("       SAND WORKS - TRIP AUDIT REPORT         ")
                            appendLine("==============================================")
                            appendLine("Generated: ${sdf.format(Date(now))}")
                            appendLine("Date Scope: $dateRangeDesc")
                            appendLine("Selection: $breakdownDesc")
                            appendLine("Total Records: ${filteredTrips.size} (${activeTrips.size} Active, $voidedTripsCount Voided)")
                            appendLine("Total Accrued Pool: ${MoneyEngine.formatPaise(totalAccruedPoolPaise)}")
                            appendLine("Driver Accruals: ${MoneyEngine.formatPaise(totalDriverSharePaise)}")
                            appendLine("Labourer Accruals: ${MoneyEngine.formatPaise(totalLabourerSharePaise)}")
                            appendLine("----------------------------------------------")
                            appendLine("TRIP DETAILS:")
                            filteredTrips.forEach { t ->
                                val st = if (t.status == TripStatus.ACTIVE) "COMPLETED" else "VOIDED (${t.voidReason ?: "N/A"})"
                                appendLine("Trip #${t.tripNumber} | ${t.date} | ${t.tractorName}")
                                appendLine("  Driver: ${t.driverName} | Labourers: ${t.labourerNames.joinToString(", ")}")
                                appendLine("  Pool: ${MoneyEngine.formatPaise(t.totalPoolPaise)} | Status: $st")
                            }
                            appendLine("==============================================")
                        }
                        exportPreviewText = summary
                        onExportAudit?.invoke(summary)
                    },
                    modifier = Modifier.testTag("trip_history_export_button")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Export Audit", fontSize = 12.sp)
                }

                if (onLogTripClick != null) {
                    Button(
                        onClick = onLogTripClick,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                        modifier = Modifier.testTag("trip_history_log_trip_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Log Trip", fontSize = 12.sp)
                    }
                }
            }
        }

        // --- 2. Search Field ---
        OutlinedTextField(
            value = filterState.searchQuery,
            onValueChange = { filterState = filterState.copy(searchQuery = it) },
            label = { Text("Search by Trip #, Driver, Vehicle, or Labourer") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (filterState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { filterState = filterState.copy(searchQuery = "") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear search")
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("trip_history_search_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // --- 3. Date Range Filter Pickers & Presets ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Date:",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FilterChip(
                    selected = filterState.datePreset == "ALL",
                    onClick = { filterState = filterState.copy(datePreset = "ALL", startDate = "", endDate = "") },
                    label = { Text("All Time", fontSize = 12.sp) },
                    modifier = Modifier.testTag("date_range_preset_all")
                )
                FilterChip(
                    selected = filterState.datePreset == "TODAY",
                    onClick = { filterState = filterState.copy(datePreset = "TODAY", startDate = todayDate, endDate = todayDate) },
                    label = { Text("Today", fontSize = 12.sp) },
                    modifier = Modifier.testTag("date_range_preset_today")
                )
                FilterChip(
                    selected = filterState.datePreset == "YESTERDAY",
                    onClick = { filterState = filterState.copy(datePreset = "YESTERDAY", startDate = yesterdayDate, endDate = yesterdayDate) },
                    label = { Text("Yesterday", fontSize = 12.sp) },
                    modifier = Modifier.testTag("date_range_preset_yesterday")
                )
                FilterChip(
                    selected = filterState.datePreset == "THIS_WEEK",
                    onClick = { filterState = filterState.copy(datePreset = "THIS_WEEK") },
                    label = { Text("Last 7 Days", fontSize = 12.sp) },
                    modifier = Modifier.testTag("date_range_preset_week")
                )
                FilterChip(
                    selected = filterState.datePreset == "LAST_30_DAYS",
                    onClick = { filterState = filterState.copy(datePreset = "LAST_30_DAYS") },
                    label = { Text("Last 30 Days", fontSize = 12.sp) },
                    modifier = Modifier.testTag("date_range_preset_month")
                )
                FilterChip(
                    selected = filterState.datePreset == "CUSTOM_RANGE",
                    onClick = {
                        filterState = filterState.copy(datePreset = "CUSTOM_RANGE")
                        showCustomDateRangeDialog = true
                    },
                    label = {
                        val label = if (filterState.datePreset == "CUSTOM_RANGE" && filterState.startDate.isNotBlank()) {
                            "${filterState.startDate} → ${filterState.endDate.ifBlank { "..." }}"
                        } else "Custom Date Range..."
                        Text(label, fontSize = 12.sp)
                    },
                    leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(14.dp)) },
                    modifier = Modifier.testTag("date_range_preset_custom")
                )
            }

            // --- 4. Dropdown Filters for Driver, Vehicle, and Status ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Driver Dropdown
                ExposedDropdownMenuBox(
                    expanded = driverDropdownExpanded,
                    onExpandedChange = { driverDropdownExpanded = it },
                    modifier = Modifier.weight(1f).testTag("driver_dropdown_box")
                ) {
                    OutlinedTextField(
                        value = selectedDriverName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Driver", fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = driverDropdownExpanded) },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandOrange,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = driverDropdownExpanded,
                        onDismissRequest = { driverDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("All Drivers (Show All)", fontWeight = FontWeight.Bold) },
                            leadingIcon = { Icon(Icons.Default.People, contentDescription = null) },
                            onClick = {
                                filterState = filterState.copy(selectedDriverId = "ALL")
                                driverDropdownExpanded = false
                            },
                            modifier = Modifier.testTag("driver_dropdown_item_all")
                        )
                        HorizontalDivider()
                        driverOptions.forEach { (id, name) ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                leadingIcon = { Icon(Icons.Default.PersonOutline, contentDescription = null) },
                                onClick = {
                                    filterState = filterState.copy(selectedDriverId = id)
                                    driverDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("driver_dropdown_item_$id")
                            )
                        }
                    }
                }

                // Vehicle Dropdown
                ExposedDropdownMenuBox(
                    expanded = vehicleDropdownExpanded,
                    onExpandedChange = { vehicleDropdownExpanded = it },
                    modifier = Modifier.weight(1f).testTag("vehicle_dropdown_box")
                ) {
                    OutlinedTextField(
                        value = selectedTractorName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Vehicle", fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = vehicleDropdownExpanded) },
                        leadingIcon = { Icon(Icons.Default.Agriculture, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BrandOrange,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = vehicleDropdownExpanded,
                        onDismissRequest = { vehicleDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("All Vehicles (Show All)", fontWeight = FontWeight.Bold) },
                            leadingIcon = { Icon(Icons.Default.LocalShipping, contentDescription = null) },
                            onClick = {
                                filterState = filterState.copy(selectedTractorId = "ALL")
                                vehicleDropdownExpanded = false
                            },
                            modifier = Modifier.testTag("vehicle_dropdown_item_all")
                        )
                        HorizontalDivider()
                        tractorOptions.forEach { (id, name) ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                leadingIcon = { Icon(Icons.Default.Agriculture, contentDescription = null) },
                                onClick = {
                                    filterState = filterState.copy(selectedTractorId = id)
                                    vehicleDropdownExpanded = false
                                },
                                modifier = Modifier.testTag("vehicle_dropdown_item_$id")
                            )
                        }
                    }
                }
            }

            // Status Dropdown & Reset Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ExposedDropdownMenuBox(
                    expanded = statusDropdownExpanded,
                    onExpandedChange = { statusDropdownExpanded = it },
                    modifier = Modifier.weight(1f).testTag("status_dropdown_box")
                ) {
                    OutlinedTextField(
                        value = selectedStatusName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Status", fontSize = 11.sp) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusDropdownExpanded) },
                        leadingIcon = { Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = statusDropdownExpanded,
                        onDismissRequest = { statusDropdownExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("All Statuses (${trips.size})") },
                            onClick = {
                                filterState = filterState.copy(filterStatus = "ALL")
                                statusDropdownExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Completed (Active) (${trips.count { it.status == TripStatus.ACTIVE }})") },
                            onClick = {
                                filterState = filterState.copy(filterStatus = "ACTIVE")
                                statusDropdownExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Voided Records (${trips.count { it.status == TripStatus.VOIDED }})") },
                            onClick = {
                                filterState = filterState.copy(filterStatus = "VOIDED")
                                statusDropdownExpanded = false
                            }
                        )
                    }
                }

                if (filterState.isAnyFilterActive) {
                    Button(
                        onClick = { filterState = TripHistoryFilterState() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("trip_history_reset_filters_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = BrandOrange)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset", color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- 5. Financial Audit Summary Card ---
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("trip_history_audit_summary_card")
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "FINANCIAL AUDIT SUMMARY",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = BrandOrange
                        )
                        Text(
                            text = "${filteredTrips.size} Trips Found (${activeTrips.size} Active, $voidedTripsCount Voided)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    if (filterState.datePreset == "CUSTOM_RANGE" && filterState.startDate.isNotBlank()) {
                        Surface(
                            color = BrandOrange.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "${filterState.startDate} → ${filterState.endDate}",
                                style = MaterialTheme.typography.labelSmall,
                                color = BrandOrange,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Total Accrued Pool", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = MoneyEngine.formatPaise(totalAccruedPoolPaise),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = BrandSandGold
                        )
                    }
                    Column {
                        Text("Driver Accrued", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = MoneyEngine.formatPaise(totalDriverSharePaise),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Column {
                        Text("Labourer Accrued", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = MoneyEngine.formatPaise(totalLabourerSharePaise),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // --- 6. Content Section: Loading, Error, Empty, or List State ---
        when {
            isLoading -> {
                LoadingStateView(
                    message = "Loading completed trip audit records...",
                    modifier = Modifier.weight(1f)
                )
            }
            errorMessage != null -> {
                ErrorStateView(
                    errorMessage = errorMessage,
                    onRetry = { onRetry?.invoke() },
                    modifier = Modifier.weight(1f)
                )
            }
            trips.isEmpty() -> {
                // Entire database is empty
                EmptyStateView(
                    icon = Icons.Default.LocalShipping,
                    title = "No Completed Trips Recorded Yet",
                    message = "No sand hauling trips have been completed in the system. When drivers or owners record trips, complete financial breakdown and audit records will appear here.",
                    actionLabel = if (onLogTripClick != null) "Log First Trip" else null,
                    onAction = onLogTripClick,
                    modifier = Modifier.weight(1f)
                )
            }
            filteredTrips.isEmpty() -> {
                // Filters resulted in empty list
                EmptyStateView(
                    icon = Icons.Default.FilterAltOff,
                    title = "No Trips Match Criteria",
                    message = "No trips matched your selected date range (${filterState.datePreset}), driver (${selectedDriverName}), or vehicle (${selectedTractorName}).",
                    actionLabel = "Reset All Filters",
                    onAction = { filterState = TripHistoryFilterState() },
                    modifier = Modifier.weight(1f)
                )
            }
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp)
                        .testTag("trip_history_list"),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredTrips, key = { it.id }) { trip ->
                        TripHistoryItemCard(
                            trip = trip,
                            isOwner = currentUser?.role == Role.OWNER,
                            onClick = { viewingTripDetails = trip },
                            onVoidClick = {
                                tripToVoid = trip
                                voidReasonInput = ""
                                voidReasonError = false
                            },
                            onEditClick = { onEditTrip?.invoke(trip) }
                        )
                    }
                }
            }
        }
    }

    // --- Date Range Picker Dialog ---
    if (showCustomDateRangeDialog) {
        CustomDateRangePickerDialog(
            initialStartDate = filterState.startDate.ifBlank { todayDate },
            initialEndDate = filterState.endDate.ifBlank { todayDate },
            onApply = { start, end ->
                filterState = filterState.copy(
                    datePreset = "CUSTOM_RANGE",
                    startDate = start,
                    endDate = end
                )
                showCustomDateRangeDialog = false
            },
            onDismiss = { showCustomDateRangeDialog = false }
        )
    }

    // --- Viewing Full Trip Detail / Audit Breakdown Dialog ---
    if (viewingTripDetails != null) {
        TripAuditDetailDialog(
            trip = viewingTripDetails!!,
            currentUser = currentUser,
            onDismiss = { viewingTripDetails = null },
            onVoid = { trip ->
                viewingTripDetails = null
                tripToVoid = trip
                voidReasonInput = ""
                voidReasonError = false
            },
            onEdit = { trip ->
                viewingTripDetails = null
                onEditTrip?.invoke(trip)
            }
        )
    }

    // --- Void Trip Confirmation Dialog ---
    if (tripToVoid != null) {
        AlertDialog(
            onDismissRequest = { tripToVoid = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = SemanticError)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Void Trip #${tripToVoid!!.tripNumber}")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Are you sure you want to void Trip #${tripToVoid!!.tripNumber} conducted on ${tripToVoid!!.date} by ${tripToVoid!!.driverName}?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "Voiding this trip will reverse the ${MoneyEngine.formatPaise(tripToVoid!!.totalPoolPaise)} accrual in daily accounting. A non-empty reason is required for financial auditing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = voidReasonInput,
                        onValueChange = {
                            voidReasonInput = it
                            if (it.isNotBlank()) voidReasonError = false
                        },
                        label = { Text("Auditing Void Reason (Mandatory)") },
                        placeholder = { Text("e.g. Mechanical breakdown, duplicate record, cancellation") },
                        isError = voidReasonError,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("void_trip_reason_input"),
                        shape = RoundedCornerShape(10.dp)
                    )
                    if (voidReasonError) {
                        Text("Reason cannot be blank.", color = SemanticError, style = MaterialTheme.typography.labelSmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (voidReasonInput.trim().isEmpty()) {
                            voidReasonError = true
                        } else {
                            onVoidTrip?.invoke(tripToVoid!!, voidReasonInput.trim())
                            tripToVoid = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SemanticError),
                    modifier = Modifier.testTag("confirm_void_trip_button")
                ) {
                    Text("Confirm Void")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { tripToVoid = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // --- Export Preview & Share Dialog ---
    if (exportPreviewText != null) {
        AlertDialog(
            onDismissRequest = { exportPreviewText = null },
            title = { Text("Export Trip History Audit") },
            text = {
                Column {
                    Text("The audit summary below can be shared or saved for financial record keeping:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)
                    ) {
                        Text(
                            text = exportPreviewText!!,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "SAND WORKS Trip History Audit")
                            putExtra(Intent.EXTRA_TEXT, exportPreviewText)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Trip History Audit"))
                        exportPreviewText = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandOrange)
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share / Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { exportPreviewText = null }) {
                    Text("Close")
                }
            }
        )
    }
}

/**
 * Individual Trip Card in Trip History view
 */
@Composable
fun TripHistoryItemCard(
    trip: Trip,
    isOwner: Boolean,
    onClick: () -> Unit,
    onVoidClick: (() -> Unit)? = null,
    onEditClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isVoided = trip.status == TripStatus.VOIDED
    val driverShare = trip.sharesPaise[trip.driverId] ?: 0L

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isVoided) SemanticError.copy(alpha = 0.06f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("trip_card_${trip.tripNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Trip #, Date, Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isVoided) SemanticError else BrandOrange)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "#${trip.tripNumber}",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = trip.date,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                StatusBadge(status = trip.status.name)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Vehicle and Driver Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.Agriculture,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = BrandOrange
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = trip.tractorName,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = trip.driverName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Labourers Summary
            if (trip.labourerNames.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${trip.labourerNames.size} Labourers: ${trip.labourerNames.joinToString(", ")}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(8.dp))

            // Financial Summary & Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Total Pool: ${MoneyEngine.formatPaise(trip.totalPoolPaise)}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (isVoided) SemanticError else BrandSandGold
                    )
                    Text(
                        text = "Driver: ${MoneyEngine.formatPaise(driverShare)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (isOwner && !isVoided) {
                        if (onEditClick != null) {
                            IconButton(onClick = onEditClick, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Trip", tint = BrandSandGold, modifier = Modifier.size(18.dp))
                            }
                        }
                        if (onVoidClick != null) {
                            IconButton(onClick = onVoidClick, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Void Trip", tint = SemanticError, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                    IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Details", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // Void banner if voided
            if (isVoided && !trip.voidReason.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = SemanticError.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Void Reason: ${trip.voidReason}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SemanticError,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * Custom Date Range Picker Dialog with Start and End Date Inputs
 */
@Composable
fun CustomDateRangePickerDialog(
    initialStartDate: String,
    initialEndDate: String,
    onApply: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val today = remember { sdf.format(Date()) }

    var startDate by remember { mutableStateOf(initialStartDate) }
    var endDate by remember { mutableStateOf(initialEndDate) }
    var errorText by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("custom_date_range_dialog")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Select Date Range",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Text(
                    text = "Specify start and end date (format YYYY-MM-DD) for auditing records:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Start Date Input
                OutlinedTextField(
                    value = startDate,
                    onValueChange = {
                        startDate = it
                        errorText = null
                    },
                    label = { Text("Start Date (YYYY-MM-DD)") },
                    trailingIcon = {
                        TextButton(onClick = { startDate = today }) {
                            Text("Today", fontSize = 11.sp)
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("range_start_date_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                // End Date Input
                OutlinedTextField(
                    value = endDate,
                    onValueChange = {
                        endDate = it
                        errorText = null
                    },
                    label = { Text("End Date (YYYY-MM-DD)") },
                    trailingIcon = {
                        TextButton(onClick = { endDate = today }) {
                            Text("Today", fontSize = 11.sp)
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("range_end_date_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                if (errorText != null) {
                    Text(
                        text = errorText!!,
                        color = SemanticError,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            val s = startDate.trim()
                            val e = endDate.trim()
                            if (s.isEmpty() || e.isEmpty()) {
                                errorText = "Both start and end dates are required."
                            } else if (s.length != 10 || e.length != 10) {
                                errorText = "Please use the format YYYY-MM-DD (e.g. 2026-10-01)."
                            } else if (s > e) {
                                errorText = "Start date cannot be after end date."
                            } else {
                                onApply(s, e)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandOrange),
                        modifier = Modifier.weight(1f).testTag("apply_date_range_button")
                    ) {
                        Text("Apply Range")
                    }
                }
            }
        }
    }
}

/**
 * Detailed Trip Audit Dialog showing complete audit breakdown
 */
@Composable
fun TripAuditDetailDialog(
    trip: Trip,
    currentUser: User?,
    onDismiss: () -> Unit,
    onVoid: ((Trip) -> Unit)? = null,
    onEdit: ((Trip) -> Unit)? = null
) {
    val isOwner = currentUser?.role == Role.OWNER
    val isVoided = trip.status == TripStatus.VOIDED
    val timeFormatted = remember(trip.timestamp) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        sdf.format(Date(trip.timestamp))
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("trip_audit_detail_dialog")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Trip #${trip.tripNumber} Audit Details",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    StatusBadge(status = trip.status.name)
                }

                HorizontalDivider()

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Date & Recorded Time: $timeFormatted", style = MaterialTheme.typography.bodySmall)
                    Text("Tractor: ${trip.tractorName} (ID: ${trip.tractorId})", style = MaterialTheme.typography.bodySmall)
                    Text("Driver: ${trip.driverName}", style = MaterialTheme.typography.bodySmall)
                    Text("Participating Labourers (${trip.labourerNames.size}):", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                    if (trip.labourerNames.isEmpty()) {
                        Text("  None (Solo Driver trip)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        trip.labourerNames.forEach { name ->
                            Text("  • $name", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Accrued Financial Distribution (Paise)", fontWeight = FontWeight.Bold, color = BrandSandGold, fontSize = 12.sp)
                        Text("Total Trip Pool: ${MoneyEngine.formatPaise(trip.totalPoolPaise)}", style = MaterialTheme.typography.bodySmall)
                        trip.sharesPaise.forEach { (uid, share) ->
                            val label = if (uid == trip.driverId) "${trip.driverName} (Driver)"
                            else "Labourer ($uid)"
                            Text("  $label: ${MoneyEngine.formatPaise(share)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                if (isVoided && !trip.voidReason.isNullOrBlank()) {
                    Surface(
                        color = SemanticError.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Void Reason: ${trip.voidReason}",
                            color = SemanticError,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isOwner && !isVoided) {
                        if (onVoid != null) {
                            OutlinedButton(
                                onClick = { onVoid(trip) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SemanticError),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Void Trip")
                            }
                        }
                        if (onEdit != null) {
                            Button(
                                onClick = { onEdit(trip) },
                                colors = ButtonDefaults.buttonColors(containerColor = BrandSandGold),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Edit")
                            }
                        }
                    }
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = if (isOwner && !isVoided) Modifier.wrapContentWidth() else Modifier.fillMaxWidth()
                    ) {
                        Text("Close", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}
